package com.ramboost

import android.content.Context

/**
 * Modo Jogo: guarda os valores atuais, aplica ajustes de desempenho e depois restaura.
 * Com root: CPU em performance (ou piso de 75%), swappiness baixo, RAM limpa, `cmd game mode performance`.
 * Sem root: só limpa a RAM.
 */
object GameMode {

    private val PKG = Regex("^[A-Za-z0-9_.]+$")
    private val GAME_PROFILE = Profile("game", "Jogo", 30, 50, 25, 8)

    fun enter(ctx: Context, pkg: String): String {
        if (!PKG.matches(pkg)) return "nome de pacote inválido"

        if (!RootShell.isRootAvailable()) {
            return Optimizer.boost(ctx) + " — sem root só dá para limpar a RAM"
        }

        val prefs = Prefs(ctx)
        if (!prefs.gameActive) {
            prefs.gameSnapshot = Cpu.snapshot()
            prefs.gameActive = true
        }

        val usePerf = "performance" in Cpu.availableGovernors()
        Cpu.boostForGame(usePerf)
        Tuning.apply(GAME_PROFILE)
        RootShell.run(
            "sync",
            "am kill-all",
            "echo 3 > /proc/sys/vm/drop_caches",
            "echo 1 > /proc/sys/vm/compact_memory",
            "cmd game mode performance $pkg 2>/dev/null"
        )

        val cpu = if (usePerf) "CPU em performance" else "CPU com piso de 75%"
        return "$cpu, swappiness 30, RAM limpa"
    }

    /** O jogo ainda está com processo vivo? (root) */
    fun isRunning(pkg: String): Boolean {
        if (!PKG.matches(pkg)) return false
        return RootShell.run("pidof $pkg", timeoutSec = 10).out.isNotBlank()
    }

    fun exit(ctx: Context): String {
        val prefs = Prefs(ctx)
        if (!prefs.gameActive) return "nada para restaurar"
        val snap = prefs.gameSnapshot
        if (snap != null) {
            RootShell.run(*Cpu.restoreCommands(snap).toTypedArray())
        }
        prefs.gameActive = false
        prefs.gameSnapshot = null
        return "ajustes de CPU e memória restaurados"
    }
}
