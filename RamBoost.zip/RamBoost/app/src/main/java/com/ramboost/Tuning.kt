package com.ramboost

import java.io.File

data class Profile(
    val id: String,
    val label: String,
    val swappiness: Int,
    val vfsCachePressure: Int,
    val dirtyRatio: Int,
    val dirtyBackgroundRatio: Int
)

object Tuning {

    val profiles = listOf(
        Profile("balanced", "Equilibrado", 60, 100, 20, 10),
        Profile("performance", "Desempenho", 40, 50, 25, 8),
        Profile("ram_saver", "Economia de RAM", 100, 150, 15, 5)
    )

    fun apply(p: Profile): RootShell.Result = RootShell.run(
        "echo ${p.swappiness} > /proc/sys/vm/swappiness",
        "echo ${p.vfsCachePressure} > /proc/sys/vm/vfs_cache_pressure",
        "echo ${p.dirtyRatio} > /proc/sys/vm/dirty_ratio",
        "echo ${p.dirtyBackgroundRatio} > /proc/sys/vm/dirty_background_ratio"
    )

    /** Valores atuais do kernel (leitura normalmente funciona sem root). */
    fun current(): String {
        fun r(name: String): String =
            try {
                File("/proc/sys/vm/$name").readText().trim()
            } catch (_: Exception) {
                "?"
            }
        return "swappiness ${r("swappiness")} · vfs_cache_pressure ${r("vfs_cache_pressure")}\n" +
            "dirty_ratio ${r("dirty_ratio")} · dirty_background_ratio ${r("dirty_background_ratio")}"
    }

    fun hasZram(): Boolean = File("/sys/block/zram0").exists()

    /** Recria o zRAM com o tamanho informado (root). */
    fun setZram(mb: Int): RootShell.Result {
        if (!hasZram()) return RootShell.Result(false, "", "este aparelho não tem /sys/block/zram0")
        val bytes = mb.toLong() * 1024L * 1024L
        return RootShell.run(
            "swapoff /dev/block/zram0",
            "echo 1 > /sys/block/zram0/reset",
            "echo $bytes > /sys/block/zram0/disksize",
            "mkswap /dev/block/zram0",
            "swapon /dev/block/zram0",
            timeoutSec = 60
        )
    }
}
