package com.ramboost

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder

/** Fica de olho no jogo e restaura os ajustes quando ele fecha. */
class GameService : Service() {

    companion object {
        const val ACTION_START = "com.ramboost.GAME_START"
        const val ACTION_STOP = "com.ramboost.GAME_STOP"
        const val EXTRA_PKG = "pkg"
        private const val CHANNEL = "game"
        private const val NOTIF_ID = 1

        fun start(ctx: Context, pkg: String) {
            val i = Intent(ctx, GameService::class.java).setAction(ACTION_START).putExtra(EXTRA_PKG, pkg)
            ctx.startForegroundService(i)
        }
    }

    private var thread: Thread? = null

    @Volatile
    private var stopRequested = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val pkg = intent.getStringExtra(EXTRA_PKG)
                if (pkg == null) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                val n = buildNotification("Monitorando $pkg")
                if (Build.VERSION.SDK_INT >= 34) {
                    startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
                } else {
                    startForeground(NOTIF_ID, n)
                }
                if (thread?.isAlive != true) {
                    stopRequested = false
                    thread = Thread { monitor(pkg) }.also { it.start() }
                }
            }

            ACTION_STOP -> {
                stopRequested = true
                val t = thread
                if (t != null && t.isAlive) {
                    t.interrupt()
                } else {
                    Thread {
                        GameMode.exit(this)
                        finishService()
                    }.start()
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun monitor(pkg: String) {
        try {
            var seen = false
            var missing = 0
            while (!stopRequested) {
                Thread.sleep(5000)
                if (stopRequested) break
                if (GameMode.isRunning(pkg)) {
                    seen = true
                    missing = 0
                } else {
                    missing++
                    // jogo fechou (2 checagens seguidas) ou nunca abriu (~40 s)
                    if ((seen && missing >= 2) || (!seen && missing >= 8)) break
                }
            }
        } catch (_: InterruptedException) {
        }
        GameMode.exit(this)
        finishService()
    }

    private fun finishService() {
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Modo Jogo", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, GameService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_stat),
            "Sair e restaurar",
            stop
        ).build()
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Modo Jogo ativo")
            .setContentText(text)
            .setOngoing(true)
            .addAction(action)
            .build()
    }
}
