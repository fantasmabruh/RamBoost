package com.ramboost

import java.io.File

data class MemInfo(
    val totalKb: Long,
    val availKb: Long,
    val cachedKb: Long,
    val swapTotalKb: Long,
    val swapFreeKb: Long
) {
    val usedKb: Long get() = (totalKb - availKb).coerceAtLeast(0)
    val usedPercent: Int get() = if (totalKb == 0L) 0 else ((usedKb * 100) / totalKb).toInt()
    val swapUsedKb: Long get() = (swapTotalKb - swapFreeKb).coerceAtLeast(0)
}

object MemReader {

    fun read(): MemInfo {
        val map = HashMap<String, Long>()
        try {
            File("/proc/meminfo").forEachLine { line ->
                val parts = line.split(":")
                if (parts.size == 2) {
                    val v = parts[1].trim().split(" ")[0].toLongOrNull()
                    if (v != null) map[parts[0].trim()] = v
                }
            }
        } catch (_: Exception) {
        }
        val total = map["MemTotal"] ?: 0L
        val avail = map["MemAvailable"] ?: ((map["MemFree"] ?: 0L) + (map["Cached"] ?: 0L))
        return MemInfo(
            totalKb = total,
            availKb = avail,
            cachedKb = map["Cached"] ?: 0L,
            swapTotalKb = map["SwapTotal"] ?: 0L,
            swapFreeKb = map["SwapFree"] ?: 0L
        )
    }

    fun format(kb: Long): String =
        if (kb >= 1024L * 1024L) String.format("%.2f GB", kb / 1048576.0)
        else "${kb / 1024} MB"
}
