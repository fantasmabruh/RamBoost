package com.ramboost

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.os.Build
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private companion object {
        val BG = Color.parseColor("#0F1115")
        val CARD = Color.parseColor("#181B22")
        val BTN = Color.parseColor("#252A33")
        val ACCENT = Color.parseColor("#00E0A4")
        val WARN = Color.parseColor("#FFB020")
        val TXT = Color.parseColor("#EDEFF3")
        val MUTED = Color.parseColor("#8A92A0")
    }

    private val worker = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: Prefs

    private lateinit var rootText: TextView
    private lateinit var ramText: TextView
    private lateinit var ramDetail: TextView
    private lateinit var swapText: TextView
    private lateinit var ramBar: ProgressBar
    private lateinit var tuningText: TextView
    private lateinit var logText: TextView
    private lateinit var cpuText: TextView
    private lateinit var gameText: TextView
    private lateinit var gameStatus: TextView
    private var ioText: TextView? = null

    private var rooted = false
    private val logLines = ArrayDeque<String>()

    private val ticker = object : Runnable {
        override fun run() {
            refreshRam()
            refreshCpu()
            refreshGame()
            ui.postDelayed(this, 2000)
        }
    }

    // ---------- helpers de UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int = 16) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun label(text: String, sizeSp: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = sizeSp
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(CARD)
            setPadding(dp(16), dp(14), dp(16), dp(16))
        }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12) }
        parent.addView(c, lp)
        c.addView(label(title, 12f, MUTED, true))
        return c
    }

    private fun button(text: String, primary: Boolean = false, onClick: () -> Unit) =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            setTextColor(if (primary) BG else TXT)
            background = rounded(if (primary) ACCENT else BTN, 12)
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(48)
            ).apply { topMargin = dp(8) }
        }

    /** Linha de botões pequenos lado a lado. */
    private fun buttonRow(items: List<Pair<String, () -> Unit>>): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((name, action) in items) {
            val b = button(name) { action() }
            b.textSize = 12f
            b.setPadding(0, 0, 0, 0)
            b.layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply {
                topMargin = dp(8)
                marginStart = dp(3)
                marginEnd = dp(3)
            }
            row.addView(b)
        }
        return row
    }

    private fun log(s: String) {
        logLines.addFirst(s)
        while (logLines.size > 30) logLines.removeLast()
        logText.text = logLines.joinToString("\n")
    }

    /** Roda uma ação em segundo plano e registra o resultado no log. */
    private fun task(label: String, needsRoot: Boolean, block: () -> String) {
        if (needsRoot && !rooted) {
            log("⚠ $label: precisa de root.")
            return
        }
        log("▶ $label…")
        worker.execute {
            val msg = try {
                block()
            } catch (e: Exception) {
                "erro: ${e.message}"
            }
            ui.post {
                log("✔ $label: $msg")
                refreshRam()
                refreshTuning()
                refreshCpu()
                refreshGame()
            }
        }
    }

    // ---------- tela ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val scroll = ScrollView(this).apply {
            setBackgroundColor(BG)
            isFillViewport = true
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(label("RamBoost", 30f, TXT, true))
        rootText = label("Verificando root…", 13f, MUTED)
        root.addView(rootText)

        // --- RAM ---
        val ramCard = card(root, "MEMÓRIA RAM")
        ramText = label("—", 24f, TXT, true)
        ramDetail = label("", 13f, MUTED)
        swapText = label("", 13f, MUTED)
        ramBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(ACCENT)
            progressBackgroundTintList = ColorStateList.valueOf(BTN)
        }
        ramCard.addView(ramText)
        ramCard.addView(
            ramBar,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(10))
                .apply { topMargin = dp(8); bottomMargin = dp(8) }
        )
        ramCard.addView(ramDetail)
        ramCard.addView(swapText)

        // --- Modo Jogo ---
        val gameCard = card(root, "🎮 MODO JOGO")
        gameText = label("", 15f, TXT, true)
        gameStatus = label("", 12f, MUTED)
        gameCard.addView(gameText)
        gameCard.addView(gameStatus)
        gameCard.addView(button("Escolher jogo") { pickGame() })
        gameCard.addView(button("🚀  Abrir jogo com Modo Jogo", primary = true) { startGame() })
        gameCard.addView(button("↩  Sair do Modo Jogo (restaurar)") {
            task("Restaurar ajustes", true) { GameMode.exit(this) }
        })

        // --- Ações ---
        val actions = card(root, "AÇÕES RÁPIDAS")
        actions.addView(button("⚡  Limpar RAM agora", primary = true) {
            task("Limpar RAM", false) {
                Optimizer.boost(this)
            }
        })
        actions.addView(button("🧹  Limpar cache de todos os apps (root)") {
            task("Limpar cache", true) { Optimizer.trimCaches() }
        })
        actions.addView(button("💾  TRIM do armazenamento (root)") {
            task("TRIM", true) { Optimizer.fstrim() }
        })

        // --- Perfis de kernel ---
        val tuning = card(root, "PERFIS DE KERNEL (root)")
        tuningText = label("", 13f, TXT)
        tuning.addView(tuningText)
        for (p in Tuning.profiles) {
            tuning.addView(
                button("${p.label}   ·   swap ${p.swappiness} / cache ${p.vfsCachePressure}") {
                    task("Perfil ${p.label}", true) {
                        val r = Tuning.apply(p)
                        if (r.ok) {
                            prefs.profileId = p.id
                            "aplicado"
                        } else {
                            "falhou: ${r.err}"
                        }
                    }
                }
            )
        }
        val sw = Switch(this).apply {
            text = "Aplicar o último perfil ao ligar o aparelho"
            setTextColor(TXT)
            isChecked = prefs.applyOnBoot
            setOnCheckedChangeListener { _, checked -> prefs.applyOnBoot = checked }
        }
        tuning.addView(
            sw,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(14) }
        )

        // --- zRAM ---
        val zram = card(root, "zRAM / SWAP COMPRIMIDO (root)")
        zram.addView(label("Recria o zRAM com o tamanho escolhido. Pode travar o aparelho por um instante.", 12f, MUTED))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (mb in listOf(512, 1024, 2048, 3072)) {
            val name = if (mb >= 1024) "${mb / 1024} GB" else "$mb MB"
            val b = button(name) {
                task("zRAM $name", true) {
                    val r = Tuning.setZram(mb)
                    if (r.ok) "aplicado" else "falhou: ${r.err.ifBlank { "verifique se o aparelho usa zram0" }}"
                }
            }
            b.layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply {
                topMargin = dp(10)
                marginStart = dp(3)
                marginEnd = dp(3)
            }
            row.addView(b)
        }
        zram.addView(row)

        // --- CPU ---
        val cpuCard = card(root, "CPU (root)")
        cpuText = label("", 13f, TXT)
        cpuCard.addView(cpuText)

        val govs = Cpu.availableGovernors().ifEmpty { listOf("performance", "schedutil", "powersave") }
        cpuCard.addView(label("Governor", 12f, MUTED).apply { setPadding(0, dp(10), 0, 0) })
        cpuCard.addView(
            buttonRow(
                govs.take(4).map { g ->
                    g to {
                        task("Governor $g", true) {
                            if (Cpu.setGovernor(g)) "aplicado" else "o kernel recusou esse governor"
                        }
                    }
                }
            )
        )
        cpuCard.addView(label("Frequência mínima (piso)", 12f, MUTED).apply { setPadding(0, dp(10), 0, 0) })
        cpuCard.addView(
            buttonRow(
                listOf(0, 50, 75, 100).map { p ->
                    "$p%" to {
                        task("CPU piso $p%", true) {
                            Cpu.setMinPercent(p)
                            "aplicado"
                        }
                    }
                }
            )
        )
        cpuCard.addView(label("Limite de frequência máxima (teto)", 12f, MUTED).apply { setPadding(0, dp(10), 0, 0) })
        cpuCard.addView(
            buttonRow(
                listOf(100, 75, 50).map { p ->
                    "$p%" to {
                        task("CPU teto $p%", true) {
                            Cpu.setMaxPercent(p)
                            "aplicado"
                        }
                    }
                }
            )
        )

        // --- I/O ---
        val ios = Cpu.ioSchedulers()
        if (ios.isNotEmpty()) {
            val ioCard = card(root, "I/O DO ARMAZENAMENTO (root)")
            ioText = label("", 13f, TXT)
            ioCard.addView(ioText)
            ioCard.addView(
                buttonRow(
                    ios.take(4).map { s ->
                        s to {
                            task("I/O $s", true) {
                                if (Cpu.setIo(s)) "aplicado" else "o kernel recusou esse scheduler"
                            }
                        }
                    }
                )
            )
        }

        // --- Log ---
        val logCard = card(root, "LOG")
        logText = label("Pronto.", 12f, MUTED)
        logCard.addView(logText)

        // checa root fora da thread principal
        worker.execute {
            val ok = RootShell.isRootAvailable(true)
            ui.post {
                rooted = ok
                rootText.text =
                    if (ok) "● Root ativo — todas as funções liberadas"
                    else "○ Sem root — só o modo básico funciona"
                rootText.setTextColor(if (ok) ACCENT else WARN)
            }
        }

        refreshRam()
        refreshTuning()
        refreshCpu()
        refreshGame()

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        ui.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(ticker)
    }

    override fun onDestroy() {
        super.onDestroy()
        worker.shutdown()
    }

    private fun refreshRam() {
        val m = MemReader.read()
        ramText.text = "${MemReader.format(m.usedKb)} / ${MemReader.format(m.totalKb)}"
        ramBar.progress = m.usedPercent
        ramDetail.text = "Em uso ${m.usedPercent}% · Disponível ${MemReader.format(m.availKb)} · Cache ${MemReader.format(m.cachedKb)}"
        swapText.text =
            if (m.swapTotalKb > 0) "Swap/zRAM: ${MemReader.format(m.swapUsedKb)} / ${MemReader.format(m.swapTotalKb)}"
            else "Swap/zRAM: desativado"
    }

    private fun pickGame() {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.applicationInfo }
            .filter { it.packageName != packageName }
            .filter {
                (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
                    (it.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
            }
            .distinctBy { it.packageName }
            .map { it.packageName to pm.getApplicationLabel(it).toString() }
            .sortedBy { it.second.lowercase() }

        if (apps.isEmpty()) {
            log("⚠ Nenhum app encontrado.")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Escolha o jogo")
            .setItems(apps.map { it.second }.toTypedArray()) { _, i ->
                prefs.gamePackage = apps[i].first
                prefs.gameName = apps[i].second
                log("🎮 Jogo escolhido: ${apps[i].second}")
                refreshGame()
            }
            .show()
    }

    private fun startGame() {
        val pkg = prefs.gamePackage
        if (pkg == null) {
            log("⚠ Escolha um jogo primeiro.")
            return
        }
        log("▶ Modo Jogo: preparando ${prefs.gameName}…")
        worker.execute {
            val msg = try {
                GameMode.enter(this, pkg)
            } catch (e: Exception) {
                "erro: ${e.message}"
            }
            ui.post {
                log("✔ Modo Jogo: $msg")
                // o serviço precisa subir enquanto o app ainda está na tela
                if (prefs.gameActive) GameService.start(this, pkg)
                val launch = packageManager.getLaunchIntentForPackage(pkg)
                if (launch != null) startActivity(launch) else log("⚠ Não consegui abrir $pkg")
                refreshRam()
                refreshCpu()
                refreshGame()
            }
        }
    }

    private fun refreshCpu() {
        cpuText.text = Cpu.summary()
        ioText?.text = "Scheduler atual: ${Cpu.ioCurrent()}"
    }

    private fun refreshGame() {
        gameText.text = "Jogo: ${prefs.gameName ?: "nenhum escolhido"}"
        gameStatus.text =
            if (prefs.gameActive) "● Modo Jogo ativo — ao fechar o jogo, os ajustes voltam sozinhos"
            else "○ Inativo"
        gameStatus.setTextColor(if (prefs.gameActive) ACCENT else MUTED)
    }

    private fun refreshTuning() {
        val saved = Tuning.profiles.firstOrNull { it.id == prefs.profileId }?.label ?: "nenhum"
        tuningText.text = Tuning.current() + "\nPerfil salvo: $saved"
    }
}
