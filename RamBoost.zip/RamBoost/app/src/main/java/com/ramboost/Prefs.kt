package com.ramboost

import android.content.Context

class Prefs(ctx: Context) {

    private val sp = ctx.getSharedPreferences("ramboost", Context.MODE_PRIVATE)

    var profileId: String?
        get() = sp.getString("profile", null)
        set(v) {
            sp.edit().putString("profile", v).apply()
        }

    var gamePackage: String?
        get() = sp.getString("game_pkg", null)
        set(v) {
            sp.edit().putString("game_pkg", v).apply()
        }

    var gameName: String?
        get() = sp.getString("game_name", null)
        set(v) {
            sp.edit().putString("game_name", v).apply()
        }

    var gameActive: Boolean
        get() = sp.getBoolean("game_active", false)
        set(v) {
            sp.edit().putBoolean("game_active", v).apply()
        }

    var gameSnapshot: String?
        get() = sp.getString("game_snapshot", null)
        set(v) {
            sp.edit().putString("game_snapshot", v).apply()
        }

    var applyOnBoot: Boolean
        get() = sp.getBoolean("boot", false)
        set(v) {
            sp.edit().putBoolean("boot", v).apply()
        }
}
