package com.ramboost

import java.io.File

/** Controle de CPU e do scheduler de I/O via sysfs (escrita exige root). */
object Cpu {

    private const val BASE = "/sys/devices/system/cpu"
    private val SAFE = Regex("^[A-Za-z0-9_.-]+$")
    private val GOV_ORDER = listOf("performance", "schedutil", "ondemand", "powersave", "interactive", "conservative")

    private fun read(path: String): String? =
        try {
            File(path).readText().trim().ifEmpty { null }
        } catch (_: Exception) {
            null
        }

    fun cores(): List<Int> =
        (File(BASE).listFiles() ?: emptyArray())
            .mapNotNull { Regex("cpu([0-9]+)").matchEntire(it.name)?.groupValues?.get(1)?.toInt() }
            .sorted()

    fun governor(): String = read("$BASE/cpu0/cpufreq/scaling_governor") ?: "?"

    fun availableGovernors(): List<String> =
        (read("$BASE/cpu0/cpufreq/scaling_available_governors") ?: "")
            .split(" ")
            .filter { it.isNotBlank() }
            .sortedBy { g -> GOV_ORDER.indexOf(g).let { if (it < 0) 99 else it } }

    fun summary(): String {
        val freqs = cores().joinToString("  ") { c ->
            val khz = read("$BASE/cpu$c/cpufreq/scaling_cur_freq")?.toLongOrNull()
            "cpu$c ${if (khz != null) "${khz / 1000}MHz" else "—"}"
        }
        return "Governor: ${governor()}\n$freqs"
    }

    private fun forEachCore(body: String) =
        "for c in $BASE/cpu[0-9]*; do f=\$c/cpufreq; [ -d \$f ] || continue; $body; done"

    fun setGovernor(g: String): Boolean {
        if (!SAFE.matches(g)) return false
        RootShell.run(forEachCore("echo $g > \$f/scaling_governor 2>/dev/null"))
        return governor() == g
    }

    /** Piso de frequência: % da frequência máxima de cada núcleo (0 = mínimo do hardware). */
    fun setMinPercent(pct: Int) {
        val body =
            if (pct <= 0) "cat \$f/cpuinfo_min_freq > \$f/scaling_min_freq 2>/dev/null"
            else "m=\$(cat \$f/cpuinfo_max_freq); echo \$m > \$f/scaling_max_freq 2>/dev/null; " +
                "echo \$((m*$pct/100)) > \$f/scaling_min_freq 2>/dev/null"
        RootShell.run(forEachCore(body))
    }

    /** Teto de frequência: % da frequência máxima de cada núcleo (o piso volta ao mínimo). */
    fun setMaxPercent(pct: Int) {
        val body = "n=\$(cat \$f/cpuinfo_min_freq); echo \$n > \$f/scaling_min_freq 2>/dev/null; " +
            "m=\$(cat \$f/cpuinfo_max_freq); echo \$((m*$pct/100)) > \$f/scaling_max_freq 2>/dev/null"
        RootShell.run(forEachCore(body))
    }

    fun boostForGame(usePerformanceGovernor: Boolean) {
        setMinPercent(75)
        if (usePerformanceGovernor) setGovernor("performance")
    }

    // ---------- snapshot / restauração (usados pelo Modo Jogo) ----------

    fun snapshot(): String {
        val script = "for c in $BASE/cpu[0-9]*; do f=\$c/cpufreq; [ -f \$f/scaling_governor ] || continue; " +
            "n=\${c##*cpu}; " +
            "echo gov \$n \$(cat \$f/scaling_governor); " +
            "echo min \$n \$(cat \$f/scaling_min_freq); " +
            "echo max \$n \$(cat \$f/scaling_max_freq); done; " +
            "echo swap \$(cat /proc/sys/vm/swappiness); " +
            "echo vfs \$(cat /proc/sys/vm/vfs_cache_pressure)"
        return RootShell.run(script).out
    }

    fun restoreCommands(snapshot: String): List<String> {
        val mins = mutableListOf<String>()
        val maxs = mutableListOf<String>()
        val govs = mutableListOf<String>()
        val vm = mutableListOf<String>()
        for (line in snapshot.lines()) {
            val p = line.trim().split(" ")
            if (p.size == 3 && p[1].isNotEmpty() && p[1].all { it.isDigit() } && SAFE.matches(p[2])) {
                val f = "$BASE/cpu${p[1]}/cpufreq"
                when (p[0]) {
                    "min" -> mins += "echo ${p[2]} > $f/scaling_min_freq 2>/dev/null"
                    "max" -> maxs += "echo ${p[2]} > $f/scaling_max_freq 2>/dev/null"
                    "gov" -> govs += "echo ${p[2]} > $f/scaling_governor 2>/dev/null"
                }
            } else if (p.size == 2 && SAFE.matches(p[1])) {
                when (p[0]) {
                    "swap" -> vm += "echo ${p[1]} > /proc/sys/vm/swappiness"
                    "vfs" -> vm += "echo ${p[1]} > /proc/sys/vm/vfs_cache_pressure"
                }
            }
        }
        return mins + maxs + govs + vm
    }

    // ---------- scheduler de I/O ----------

    private fun ioSchedulerRaw(): String? {
        val dirs = File("/sys/block").listFiles() ?: return null
        for (d in dirs.sortedBy { it.name }) {
            val n = d.name
            if (n.startsWith("zram") || n.startsWith("loop") || n.startsWith("ram") || n.startsWith("dm-")) continue
            read("${d.path}/queue/scheduler")?.let { return it }
        }
        return null
    }

    fun ioSchedulers(): List<String> =
        ioSchedulerRaw()?.replace("[", "")?.replace("]", "")?.split(" ")?.filter { it.isNotBlank() }
            ?: emptyList()

    fun ioCurrent(): String =
        ioSchedulerRaw()?.let { Regex("\\[(.*?)]").find(it)?.groupValues?.get(1) } ?: "?"

    fun setIo(s: String): Boolean {
        if (!SAFE.matches(s)) return false
        RootShell.run(
            "for q in /sys/block/*/queue/scheduler; do " +
                "case \$q in */zram*|*/loop*|*/ram*|*/dm-*) continue;; esac; " +
                "echo $s > \$q 2>/dev/null; done"
        )
        return ioCurrent() == s
    }
}
