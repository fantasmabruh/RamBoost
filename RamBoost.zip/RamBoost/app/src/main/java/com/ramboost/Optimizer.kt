package com.ramboost

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Environment
import android.os.StatFs

object Optimizer {

    /**
     * Libera RAM.
     * Com root: sync + am kill-all + drop_caches + compact_memory.
     * Sem root: pede ao sistema para encerrar processos em segundo plano dos apps instalados.
     */
    fun boost(ctx: Context): String {
        val before = MemReader.read()
        val mode: String

        if (RootShell.isRootAvailable()) {
            RootShell.run(
                "sync",
                "am kill-all",
                "echo 3 > /proc/sys/vm/drop_caches",
                "echo 1 > /proc/sys/vm/compact_memory"
            )
            mode = "root"
        } else {
            val n = killBackground(ctx)
            mode = "sem root, $n apps notificados"
        }

        System.gc()
        Thread.sleep(1000)

        val after = MemReader.read()
        val freed = (after.availKb - before.availKb).coerceAtLeast(0)
        return "RAM livre +${MemReader.format(freed)} ($mode)"
    }

    private fun killBackground(ctx: Context): Int {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        var n = 0
        for (app in ctx.packageManager.getInstalledApplications(0)) {
            if (app.packageName == ctx.packageName) continue
            if ((app.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
            am.killBackgroundProcesses(app.packageName)
            n++
        }
        return n
    }

    /** Limpa o cache de todos os apps (root). */
    fun trimCaches(): String {
        val before = freeStorage()
        val r = RootShell.run("pm trim-caches 999G")
        val freed = (freeStorage() - before).coerceAtLeast(0)
        return if (r.ok) "cache limpo, ${freed / (1024 * 1024)} MB liberados" else "falhou: ${r.err}"
    }

    /** Roda fstrim nas partições (root). */
    fun fstrim(): String {
        val r = RootShell.run("fstrim -v /data", "fstrim -v /cache", "fstrim -v /system")
        val text = r.out.lines().filter { it.isNotBlank() }.joinToString("; ")
        return if (text.isNotEmpty()) text else if (r.ok) "concluído" else "falhou: ${r.err}"
    }

    private fun freeStorage(): Long =
        StatFs(Environment.getDataDirectory().path).availableBytes
}
