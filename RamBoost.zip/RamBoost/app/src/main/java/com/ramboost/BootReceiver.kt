package com.ramboost

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Reaplica o perfil de kernel salvo quando o aparelho liga (precisa de root). */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val prefs = Prefs(context)
        if (!prefs.applyOnBoot) return
        val profile = Tuning.profiles.firstOrNull { it.id == prefs.profileId } ?: return

        val pending = goAsync()
        Thread {
            try {
                Thread.sleep(3000)
                if (RootShell.isRootAvailable(true)) Tuning.apply(profile)
            } finally {
                pending.finish()
            }
        }.start()
    }
}
