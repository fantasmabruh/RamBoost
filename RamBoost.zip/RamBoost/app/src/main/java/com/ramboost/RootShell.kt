package com.ramboost

import java.util.concurrent.TimeUnit

/** Executa comandos como root via `su` (Magisk, KernelSU, etc). */
object RootShell {

    data class Result(val ok: Boolean, val out: String, val err: String)

    @Volatile
    private var cachedRoot: Boolean? = null

    fun isRootAvailable(force: Boolean = false): Boolean {
        if (!force) cachedRoot?.let { return it }
        val r = run("id -u")
        val has = r.ok && r.out.trim() == "0"
        cachedRoot = has
        return has
    }

    fun run(vararg commands: String, timeoutSec: Long = 30): Result {
        return try {
            val p = Runtime.getRuntime().exec("su")
            val outBuf = StringBuffer()
            val errBuf = StringBuffer()

            val tOut = Thread {
                runCatching {
                    p.inputStream.bufferedReader().forEachLine { outBuf.append(it).append('\n') }
                }
            }
            val tErr = Thread {
                runCatching {
                    p.errorStream.bufferedReader().forEachLine { errBuf.append(it).append('\n') }
                }
            }
            tOut.start()
            tErr.start()

            p.outputStream.bufferedWriter().use { w ->
                commands.forEach { w.write(it); w.write("\n") }
                w.write("exit\n")
                w.flush()
            }

            val finished = p.waitFor(timeoutSec, TimeUnit.SECONDS)
            if (!finished) p.destroyForcibly()
            tOut.join(1000)
            tErr.join(1000)

            Result(
                ok = finished && p.exitValue() == 0,
                out = outBuf.toString().trim(),
                err = errBuf.toString().trim()
            )
        } catch (e: Exception) {
            Result(false, "", e.message ?: "erro ao executar su")
        }
    }
}
