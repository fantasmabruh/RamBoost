# RamBoost

App Android (Kotlin, sem dependências externas) para otimizar a RAM e ajustar o kernel.
Funciona **com root** (Magisk / KernelSU) e tem um modo básico **sem root**.

## O que ele faz

| Função | Root? | Como funciona |
|---|---|---|
| Medidor de RAM em tempo real | não | lê `/proc/meminfo` a cada 2 s (RAM, cache, swap/zRAM) |
| Limpar RAM | sim / não | root: `sync` + `am kill-all` + `drop_caches` + `compact_memory`. Sem root: `killBackgroundProcesses` nos apps instalados |
| Limpar cache de todos os apps | sim | `pm trim-caches` |
| TRIM do armazenamento | sim | `fstrim` em `/data`, `/cache`, `/system` |
| Perfis de kernel | sim | ajusta `swappiness`, `vfs_cache_pressure`, `dirty_ratio`, `dirty_background_ratio` |
| Aplicar perfil ao ligar | sim | `BootReceiver` reaplica o último perfil no boot |
| Tamanho do zRAM | sim | recria `/dev/block/zram0` (512 MB, 1, 2 ou 3 GB) |

### Perfis

| Perfil | swappiness | vfs_cache_pressure | dirty_ratio | dirty_bg |
|---|---|---|---|---|
| Equilibrado | 60 | 100 | 20 | 10 |
| Desempenho | 40 | 50 | 25 | 8 |
| Economia de RAM | 100 | 150 | 15 | 5 |

## CPU, I/O e Modo Jogo

| Função | Root? | Como funciona |
|---|---|---|
| Governor da CPU | sim | escreve em `scaling_governor` de todos os núcleos (mostra os governors que o seu kernel oferece) |
| Piso de frequência (0 / 50 / 75 / 100 %) | sim | `scaling_min_freq` = % de `cpuinfo_max_freq` de cada núcleo |
| Teto de frequência (100 / 75 / 50 %) | sim | `scaling_max_freq`; o piso volta ao mínimo |
| Scheduler de I/O | sim | `/sys/block/*/queue/scheduler` (exceto zram/loop/ram/dm) |
| **Modo Jogo** | sim (parcial sem) | veja abaixo |

**Modo Jogo:** escolha o jogo na lista e toque em *Abrir jogo com Modo Jogo*. O app:
1. guarda os valores atuais (governor, frequências, swappiness, cache pressure);
2. coloca a CPU em `performance` (ou piso de 75 % se o governor não existir), swappiness 30, cache pressure 50;
3. limpa a RAM (`am kill-all`, `drop_caches`, `compact_memory`) e liga o Game Mode do Android (`cmd game mode performance`);
4. abre o jogo;
5. um serviço em primeiro plano confere a cada 5 s se o jogo ainda está aberto e, quando ele fecha, **restaura tudo sozinho**.

Também dá para sair antes pelo botão *Sair do Modo Jogo* ou pela notificação. Sem root, o Modo Jogo só limpa a RAM e abre o jogo.

## Como gerar o APK

**Opção A — Android Studio:** abra a pasta `RamBoost`, espere o Gradle sincronizar e use *Build > Build APK(s)*.

**Opção B — GitHub (sem instalar nada):**
1. Crie um repositório e suba esta pasta.
2. Vá em *Actions > Build APK > Run workflow*.
3. Baixe `RamBoost-debug-apk` nos artefatos da execução e instale no celular.

Requisitos: JDK 17, Android SDK 34, Gradle 8.7 (o workflow já cuida disso).

## Observações importantes

- `drop_caches` e matar apps liberam RAM na hora, mas o Android reaproveita cache sozinho e os apps
  fechados precisam reabrir (mais lento e mais bateria). O ganho real vem mais dos **perfis** e do **zRAM**.
- Mexer no zRAM e em parâmetros do kernel pode causar travamentos ou reboot em alguns aparelhos.
  Os valores voltam ao normal ao reiniciar, a menos que "Aplicar ao ligar" esteja ativo.
- Alguns fabricantes (Samsung, Xiaomi) usam outro caminho de zRAM ou bloqueiam essas escritas.
